import{ak as o}from"./index-HwNbBTkB.js";const t=()=>o().appContext.config.globalProperties;export{t as u};
