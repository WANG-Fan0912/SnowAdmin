import{gJ as t}from"./index-HwNbBTkB.js";const o=()=>t({url:"/mock/common-table/list",method:"get"}),m=()=>t({url:"/mock/custom-table/list",method:"get"});export{m as a,o as g};
