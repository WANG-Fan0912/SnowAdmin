import{gJ as e}from"./index-HwNbBTkB.js";const t=()=>e({url:"/mock/document-library/tree",method:"get"}),o=()=>e({url:"/mock/document-library/table",method:"get"});export{t as a,o as g};
