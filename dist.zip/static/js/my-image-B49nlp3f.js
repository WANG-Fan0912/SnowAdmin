const t="/static/jpg/my-image-C0e0W-Q3.jpg";export{t as m};
